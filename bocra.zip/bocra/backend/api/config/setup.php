<?php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'bocra_db');

echo "<!DOCTYPE html><html><head><title>BOCRA Setup</title><style>body{font-family:Arial;margin:50px;background:#f5f5f5}.container{max-width:800px;margin:0 auto;background:white;padding:30px;border-radius:10px}.success{color:green}.error{color:red}.btn{display:inline-block;padding:10px 20px;background:#ff6600;color:white;text-decoration:none;border-radius:5px}</style></head><body><div class='container'>";
echo "<h1>BOCRA Platform Setup</h1>";

$conn = new mysqli(DB_HOST, DB_USER, DB_PASS);
if ($conn->connect_error) die("<p class='error'>Connection failed: " . $conn->connect_error . "</p>");

$conn->query("CREATE DATABASE IF NOT EXISTS " . DB_NAME);
echo "<p class='success'>✓ Database created</p>";
$conn->select_db(DB_NAME);

$tables = [
    "users" => "CREATE TABLE IF NOT EXISTS users (
        id INT PRIMARY KEY AUTO_INCREMENT,
        user_type ENUM('citizen','company','admin') DEFAULT 'citizen',
        email VARCHAR(100) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        full_name VARCHAR(100),
        company_name VARCHAR(100),
        id_number VARCHAR(50),
        company_reg_number VARCHAR(50),
        date_of_birth DATE,
        physical_address TEXT,
        phone VARCHAR(20),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB",
    
    "complaints" => "CREATE TABLE IF NOT EXISTS complaints (
        id INT PRIMARY KEY AUTO_INCREMENT,
        complaint_number VARCHAR(50) UNIQUE NOT NULL,
        user_id INT,
        category VARCHAR(50) NOT NULL,
        provider_name VARCHAR(100) NOT NULL,
        incident_date DATE,
        description TEXT NOT NULL,
        anonymous BOOLEAN DEFAULT FALSE,
        status VARCHAR(50) DEFAULT 'Submitted',
        contact_method VARCHAR(20),
        contact_email VARCHAR(100),
        contact_phone VARCHAR(20),
        blockchain_hash VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
    ) ENGINE=InnoDB",
    
    "complaint_status_history" => "CREATE TABLE IF NOT EXISTS complaint_status_history (
        id INT PRIMARY KEY AUTO_INCREMENT,
        complaint_id INT NOT NULL,
        old_status VARCHAR(50),
        new_status VARCHAR(50),
        notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (complaint_id) REFERENCES complaints(id) ON DELETE CASCADE
    ) ENGINE=InnoDB",
    
    "attachments" => "CREATE TABLE IF NOT EXISTS attachments (
        id INT PRIMARY KEY AUTO_INCREMENT,
        complaint_id INT NOT NULL,
        file_name VARCHAR(255) NOT NULL,
        file_path VARCHAR(255) NOT NULL,
        file_size INT,
        uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (complaint_id) REFERENCES complaints(id) ON DELETE CASCADE
    ) ENGINE=InnoDB",
    
    "provider_responses" => "CREATE TABLE IF NOT EXISTS provider_responses (
        id INT PRIMARY KEY AUTO_INCREMENT,
        complaint_id INT NOT NULL,
        response TEXT NOT NULL,
        action_taken TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (complaint_id) REFERENCES complaints(id) ON DELETE CASCADE
    ) ENGINE=InnoDB",
    
    "user_sessions" => "CREATE TABLE IF NOT EXISTS user_sessions (
        id INT PRIMARY KEY AUTO_INCREMENT,
        user_id INT NOT NULL,
        token VARCHAR(255) UNIQUE NOT NULL,
        expires_at DATETIME NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB"
];

foreach ($tables as $name => $sql) {
    if ($conn->query($sql)) echo "<p class='success'>✓ $name table created</p>";
    else echo "<p class='error'>✗ Error creating $name: " . $conn->error . "</p>";
}

$adminEmail = 'admin@bocra.org.bw';
$check = $conn->query("SELECT id FROM users WHERE email = '$adminEmail'");
if ($check->num_rows == 0) {
    $adminPassword = password_hash('admin123', PASSWORD_DEFAULT);
    $conn->query("INSERT INTO users (user_type, email, password, full_name, phone) VALUES 
        ('admin', '$adminEmail', '$adminPassword', 'BOCRA Administrator', '+267 395 7755')");
    echo "<p class='success'>✓ Admin user created (admin@bocra.org.bw / admin123)</p>";
}

$citizenEmail = 'john.doe@example.com';
$check = $conn->query("SELECT id FROM users WHERE email = '$citizenEmail'");
if ($check->num_rows == 0) {
    $citizenPassword = password_hash('password123', PASSWORD_DEFAULT);
    $conn->query("INSERT INTO users (user_type, email, password, full_name, phone) VALUES 
        ('citizen', '$citizenEmail', '$citizenPassword', 'John Doe', '+267 71 234 567')");
    echo "<p class='success'>✓ Citizen user created (john.doe@example.com / password123)</p>";
}

$companyEmail = 'mascom@example.com';
$check = $conn->query("SELECT id FROM users WHERE email = '$companyEmail'");
if ($check->num_rows == 0) {
    $companyPassword = password_hash('company123', PASSWORD_DEFAULT);
    $conn->query("INSERT INTO users (user_type, email, password, company_name, phone) VALUES 
        ('company', '$companyEmail', '$companyPassword', 'Mascom Wireless', '+267 73 123 456')");
    echo "<p class='success'>✓ Company user created (mascom@example.com / company123)</p>";
}

$uploadDir = dirname(__DIR__, 2) . '/uploads';
if (!file_exists($uploadDir)) {
    mkdir($uploadDir, 0777, true);
    echo "<p class='success'>✓ Uploads directory created at: $uploadDir</p>";
}

echo "<h2>Setup Complete!</h2>";
echo "<h3>Login Credentials:</h3><ul>";
echo "<li><strong>Admin:</strong> admin@bocra.org.bw / admin123</li>";
echo "<li><strong>Citizen:</strong> john.doe@example.com / password123</li>";
echo "<li><strong>Company:</strong> mascom@example.com / company123</li>";
echo "</ul>";
echo "<a href='../../../frontend/index.html' class='btn'>Go to Platform →</a>";
echo "</div></body></html>";

$conn->close();
?>