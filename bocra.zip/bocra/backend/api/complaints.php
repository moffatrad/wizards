<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once 'config/database.php';

$conn = getConnection();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $year = date('Y');
    $countResult = $conn->query("SELECT COUNT(*) as count FROM complaints WHERE complaint_number LIKE 'BOCRA-$year-%'");
    $row = $countResult->fetch_assoc();
    $count = $row['count'] + 1;
    $complaintNumber = "BOCRA-$year-" . str_pad($count, 4, '0', STR_PAD_LEFT);
    
    $category = $conn->real_escape_string($_POST['category']);
    $providerName = $conn->real_escape_string($_POST['providerName']);
    $incidentDate = !empty($_POST['incidentDate']) ? $_POST['incidentDate'] : null;
    $description = $conn->real_escape_string($_POST['description']);
    $anonymous = isset($_POST['anonymous']) && $_POST['anonymous'] == '1' ? 1 : 0;
    $contactMethod = $conn->real_escape_string($_POST['contactMethod']);
    
    $fullName = $anonymous ? null : ($_POST['fullName'] ?? null);
    $email = $anonymous ? null : ($_POST['email'] ?? null);
    $phone = $anonymous ? null : ($_POST['phone'] ?? null);
    
    $userId = null;
    $token = $_POST['token'] ?? '';
    
    if ($token) {
        $tokenStmt = $conn->prepare("SELECT user_id FROM user_sessions WHERE token = ? AND expires_at > NOW()");
        $tokenStmt->bind_param("s", $token);
        $tokenStmt->execute();
        $tokenResult = $tokenStmt->get_result();
        if ($tokenResult->num_rows > 0) {
            $session = $tokenResult->fetch_assoc();
            $userId = $session['user_id'];
        }
    }
    
    $blockchainHash = hash('sha256', $complaintNumber . $description . time() . rand());
    
    $stmt = $conn->prepare("INSERT INTO complaints (complaint_number, user_id, category, provider_name, incident_date, description, 
            anonymous, contact_method, contact_email, contact_phone, blockchain_hash, status) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Submitted')");
    $stmt->bind_param("sisssssssss", $complaintNumber, $userId, $category, $providerName, $incidentDate, $description, 
            $anonymous, $contactMethod, $email, $phone, $blockchainHash);
    
    if ($stmt->execute()) {
        $complaintId = $conn->insert_id;
        
        $historyStmt = $conn->prepare("INSERT INTO complaint_status_history (complaint_id, old_status, new_status, notes) 
                      VALUES (?, 'New', 'Submitted', 'Complaint received and logged')");
        $historyStmt->bind_param("i", $complaintId);
        $historyStmt->execute();
        
        // Handle file uploads
        if (!empty($_FILES['attachments'])) {
            $uploadDir = dirname(__DIR__, 2) . '/uploads/';
            if (!file_exists($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }
            
            $files = $_FILES['attachments'];
            $fileCount = count($files['name']);
            
            for ($i = 0; $i < $fileCount; $i++) {
                if ($files['error'][$i] === UPLOAD_ERR_OK && $files['size'][$i] <= 10 * 1024 * 1024) {
                    $originalName = basename($files['name'][$i]);
                    $fileExt = pathinfo($originalName, PATHINFO_EXTENSION);
                    $fileName = time() . '_' . rand(1000, 9999) . '.' . $fileExt;
                    $targetFile = $uploadDir . $fileName;
                    
                    if (move_uploaded_file($files['tmp_name'][$i], $targetFile)) {
                        $attachStmt = $conn->prepare("INSERT INTO attachments (complaint_id, file_name, file_path, file_size) 
                                     VALUES (?, ?, ?, ?)");
                        $attachStmt->bind_param("issi", $complaintId, $originalName, $fileName, $files['size'][$i]);
                        $attachStmt->execute();
                    }
                }
            }
        }
        
        echo json_encode([
            'success' => true,
            'complaint_number' => $complaintNumber,
            'blockchain_hash' => $blockchainHash,
            'message' => 'Complaint submitted successfully'
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Submission failed: ' . $stmt->error]);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
}

$conn->close();
?>