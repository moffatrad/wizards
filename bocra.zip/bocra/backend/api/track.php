<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once 'config/database.php';

$conn = getConnection();
$complaintNumber = isset($_GET['number']) ? $conn->real_escape_string($_GET['number']) : '';

if ($complaintNumber) {
    $stmt = $conn->prepare("SELECT * FROM complaints WHERE complaint_number = ?");
    $stmt->bind_param("s", $complaintNumber);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result && $result->num_rows > 0) {
        $complaint = $result->fetch_assoc();
        
        $historyStmt = $conn->prepare("SELECT * FROM complaint_status_history WHERE complaint_id = ? ORDER BY created_at ASC");
        $historyStmt->bind_param("i", $complaint['id']);
        $historyStmt->execute();
        $historyResult = $historyStmt->get_result();
        $history = [];
        while ($row = $historyResult->fetch_assoc()) {
            $row['created_at'] = date('Y-m-d H:i', strtotime($row['created_at']));
            $history[] = $row;
        }
        
        $responseStmt = $conn->prepare("SELECT * FROM provider_responses WHERE complaint_id = ? ORDER BY created_at DESC LIMIT 1");
        $responseStmt->bind_param("i", $complaint['id']);
        $responseStmt->execute();
        $responseResult = $responseStmt->get_result();
        $response = $responseResult->fetch_assoc();
        if ($response) {
            $response['created_at'] = date('Y-m-d H:i', strtotime($response['created_at']));
        }
        
        echo json_encode([
            'success' => true,
            'complaint' => [
                'complaint_number' => $complaint['complaint_number'],
                'status' => $complaint['status'],
                'category' => $complaint['category'],
                'provider_name' => $complaint['provider_name'],
                'description' => $complaint['description'],
                'created_at' => date('Y-m-d H:i', strtotime($complaint['created_at'])),
                'blockchain_hash' => $complaint['blockchain_hash'],
                'history' => $history,
                'provider_response' => $response
            ]
        ]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Complaint not found']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Complaint number required']);
}

$conn->close();
?>