<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once 'config/database.php';

$conn = getConnection();

$headers = getallheaders();
$token = str_replace('Bearer ', '', $headers['Authorization'] ?? '');

if (!$token) {
    echo json_encode(['success' => false, 'message' => 'No token provided']);
    exit;
}

$stmt = $conn->prepare("SELECT u.* FROM user_sessions s JOIN users u ON s.user_id = u.id WHERE s.token = ? AND s.expires_at > NOW()");
$stmt->bind_param("s", $token);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid or expired token']);
    exit;
}

$user = $result->fetch_assoc();

if ($user['user_type'] !== 'company') {
    echo json_encode(['success' => false, 'message' => 'Access denied. Provider only.']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$complaintId = $data['complaint_id'] ?? 0;
$response = $conn->real_escape_string($data['response'] ?? '');

if (!$complaintId || !$response) {
    echo json_encode(['success' => false, 'message' => 'Complaint ID and response required']);
    exit;
}

$checkStmt = $conn->prepare("SELECT id, status FROM complaints WHERE id = ? AND provider_name = ?");
$checkStmt->bind_param("is", $complaintId, $user['company_name']);
$checkStmt->execute();
$checkResult = $checkStmt->get_result();

if ($checkResult->num_rows == 0) {
    echo json_encode(['success' => false, 'message' => 'Complaint not found or not assigned to you']);
    exit;
}

$complaint = $checkResult->fetch_assoc();

$insertStmt = $conn->prepare("INSERT INTO provider_responses (complaint_id, response) VALUES (?, ?)");
$insertStmt->bind_param("is", $complaintId, $response);

if ($insertStmt->execute()) {
    $updateStmt = $conn->prepare("UPDATE complaints SET status = 'Under Review' WHERE id = ?");
    $updateStmt->bind_param("i", $complaintId);
    $updateStmt->execute();
    
    $historyStmt = $conn->prepare("INSERT INTO complaint_status_history (complaint_id, old_status, new_status, notes) VALUES (?, ?, 'Under Review', ?)");
    $historyStmt->bind_param("iss", $complaintId, $complaint['status'], $response);
    $historyStmt->execute();
    
    echo json_encode(['success' => true, 'message' => 'Response submitted successfully']);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to submit response']);
}

$conn->close();
?>