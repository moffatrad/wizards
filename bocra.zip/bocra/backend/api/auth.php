<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

$dbPath = __DIR__ . '/config/database.php';
if (!file_exists($dbPath)) {
    echo json_encode(['success' => false, 'message' => 'Database config not found']);
    exit;
}

require_once $dbPath;

$conn = getConnection();
$data = json_decode(file_get_contents('php://input'), true);

if (!$data) {
    echo json_encode(['success' => false, 'message' => 'Invalid request - no data received']);
    exit;
}

$action = $data['action'] ?? '';

if ($action === 'login') {
    // Login code remains the same
    $email = $conn->real_escape_string($data['email'] ?? '');
    $password = $data['password'] ?? '';
    $userType = $conn->real_escape_string($data['user_type'] ?? 'citizen');
    
    if (empty($email) || empty($password)) {
        echo json_encode(['success' => false, 'message' => 'Email and password are required']);
        exit;
    }
    
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result && $result->num_rows > 0) {
        $user = $result->fetch_assoc();
        
        if (password_verify($password, $user['password'])) {
            if ($user['user_type'] !== $userType) {
                echo json_encode(['success' => false, 'message' => 'Invalid user type']);
                exit;
            }
            
            $token = bin2hex(random_bytes(32));
            $expiresAt = date('Y-m-d H:i:s', strtotime('+7 days'));
            
            $stmt2 = $conn->prepare("INSERT INTO user_sessions (user_id, token, expires_at) VALUES (?, ?, ?)");
            $stmt2->bind_param("iss", $user['id'], $token, $expiresAt);
            
            if ($stmt2->execute()) {
                echo json_encode([
                    'success' => true,
                    'token' => $token,
                    'user' => [
                        'id' => $user['id'],
                        'email' => $user['email'],
                        'full_name' => $user['full_name'],
                        'company_name' => $user['company_name'],
                        'user_type' => $user['user_type'],
                        'phone' => $user['phone']
                    ]
                ]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Failed to create session']);
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Invalid password']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'User not found']);
    }
    
} elseif ($action === 'register') {
    $userType = $conn->real_escape_string($data['user_type'] ?? '');
    $email = $conn->real_escape_string($data['email'] ?? '');
    $password = $data['password'] ?? '';
    $phone = $conn->real_escape_string($data['phone'] ?? '');
    $address = $conn->real_escape_string($data['address'] ?? '');
    
    // Basic validation
    if (empty($userType) || empty($email) || empty($password)) {
        echo json_encode(['success' => false, 'message' => 'Missing required fields']);
        exit;
    }
    
    // Email validation
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo json_encode(['success' => false, 'message' => 'Invalid email format']);
        exit;
    }
    
    // Password validation (minimum 6 characters)
    if (strlen($password) < 6) {
        echo json_encode(['success' => false, 'message' => 'Password must be at least 6 characters']);
        exit;
    }
    
    // Phone validation (Botswana format: +267XXXXXXXX)
    if (!preg_match('/^\+267[0-9]{8}$/', $phone)) {
        echo json_encode(['success' => false, 'message' => 'Phone number must be in format: +267XXXXXXXX (e.g., +26771234567)']);
        exit;
    }
    
    // Check if email already exists
    $checkStmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $checkStmt->bind_param("s", $email);
    $checkStmt->execute();
    $checkResult = $checkStmt->get_result();
    
    if ($checkResult && $checkResult->num_rows > 0) {
        echo json_encode(['success' => false, 'message' => 'Email already registered']);
        exit;
    }
    
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
    
    if ($userType === 'citizen') {
        $fullName = $conn->real_escape_string($data['full_name'] ?? '');
        $idNumber = $conn->real_escape_string($data['id_number'] ?? '');
        $dob = $conn->real_escape_string($data['date_of_birth'] ?? '');
        
        // Validate required citizen fields
        if (empty($fullName) || empty($idNumber) || empty($dob)) {
            echo json_encode(['success' => false, 'message' => 'All citizen fields are required']);
            exit;
        }
        
        // Validate Omang (exactly 9 digits)
        if (!preg_match('/^\d{9}$/', $idNumber)) {
            echo json_encode(['success' => false, 'message' => 'Omang/ID Number must be exactly 9 digits']);
            exit;
        }
        
        // Validate age (must be 18 or older)
        $birthDate = new DateTime($dob);
        $today = new DateTime();
        $age = $today->diff($birthDate)->y;
        
        if ($age < 18) {
            echo json_encode(['success' => false, 'message' => 'You must be 18 years or older to register']);
            exit;
        }
        
        // Check if Omang already exists
        $checkOmang = $conn->prepare("SELECT id FROM users WHERE id_number = ?");
        $checkOmang->bind_param("s", $idNumber);
        $checkOmang->execute();
        $omangResult = $checkOmang->get_result();
        
        if ($omangResult && $omangResult->num_rows > 0) {
            echo json_encode(['success' => false, 'message' => 'Omang/ID Number already registered']);
            exit;
        }
        
        $stmt = $conn->prepare("INSERT INTO users (user_type, email, password, full_name, id_number, date_of_birth, physical_address, phone) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssssss", $userType, $email, $hashedPassword, $fullName, $idNumber, $dob, $address, $phone);
        
    } else if ($userType === 'company') {
        $companyName = $conn->real_escape_string($data['company_name'] ?? '');
        $companyReg = $conn->real_escape_string($data['company_reg_number'] ?? '');
        
        if (empty($companyName) || empty($companyReg)) {
            echo json_encode(['success' => false, 'message' => 'All company fields are required']);
            exit;
        }
        
        // Check if company registration already exists
        $checkReg = $conn->prepare("SELECT id FROM users WHERE company_reg_number = ?");
        $checkReg->bind_param("s", $companyReg);
        $checkReg->execute();
        $regResult = $checkReg->get_result();
        
        if ($regResult && $regResult->num_rows > 0) {
            echo json_encode(['success' => false, 'message' => 'Company registration number already registered']);
            exit;
        }
        
        $stmt = $conn->prepare("INSERT INTO users (user_type, email, password, company_name, company_reg_number, physical_address, phone) 
                VALUES (?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("sssssss", $userType, $email, $hashedPassword, $companyName, $companyReg, $address, $phone);
        
    } else if ($userType === 'admin') {
        $fullName = $conn->real_escape_string($data['full_name'] ?? '');
        
        $stmt = $conn->prepare("INSERT INTO users (user_type, email, password, full_name, phone) 
                VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $userType, $email, $hashedPassword, $fullName, $phone);
        
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid user type']);
        exit;
    }
    
    if ($stmt && $stmt->execute()) {
        echo json_encode(['success' => true, 'message' => 'Registration successful']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Registration failed: ' . ($stmt ? $stmt->error : 'Statement error')]);
    }
    
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid action. Use "login" or "register"']);
}

$conn->close();
?>