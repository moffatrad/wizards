<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once 'config/database.php';

$conn = getConnection();

$headers = getallheaders();
$token = str_replace('Bearer ', '', $headers['Authorization'] ?? '');

if (!$token) {
    echo json_encode(['success' => false, 'message' => 'No token provided']);
    exit;
}

$stmt = $conn->prepare("SELECT u.* FROM user_sessions s JOIN users u ON s.user_id = u.id WHERE s.token = ? AND s.expires_at > NOW()");
$stmt->bind_param("s", $token);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid or expired token']);
    exit;
}

$user = $result->fetch_assoc();

if ($user['user_type'] !== 'company') {
    echo json_encode(['success' => false, 'message' => 'Access denied. Provider only.']);
    exit;
}

$complaintsStmt = $conn->prepare("SELECT * FROM complaints WHERE provider_name = ? ORDER BY created_at DESC");
$complaintsStmt->bind_param("s", $user['company_name']);
$complaintsStmt->execute();
$complaintsResult = $complaintsStmt->get_result();

$complaints = [];
while ($row = $complaintsResult->fetch_assoc()) {
    $row['created_at'] = date('Y-m-d H:i', strtotime($row['created_at']));
    $complaints[] = $row;
}

echo json_encode(['success' => true, 'complaints' => $complaints]);

$conn->close();
?>