<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json");

if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
    http_response_code(200);
    exit();
}

require_once 'config/database.php';

$conn = getConnection();

// Get total complaints
$totalResult = $conn->query("SELECT COUNT(*) as total FROM complaints");
$total = $totalResult->fetch_assoc()['total'];

// Get resolved complaints
$resolvedResult = $conn->query("SELECT COUNT(*) as resolved FROM complaints WHERE status = 'Resolved'");
$resolved = $resolvedResult->fetch_assoc()['resolved'];

// Get under review complaints
$reviewResult = $conn->query("SELECT COUNT(*) as review FROM complaints WHERE status = 'Under Review'");
$underReview = $reviewResult->fetch_assoc()['review'];

// Get submitted complaints
$submittedResult = $conn->query("SELECT COUNT(*) as submitted FROM complaints WHERE status = 'Submitted'");
$submitted = $submittedResult->fetch_assoc()['submitted'];

// Calculate resolution rate
$resolutionRate = $total > 0 ? round(($resolved / $total) * 100) . '%' : '0%';

// Get complaints by category
$categoryResult = $conn->query("SELECT category, COUNT(*) as count FROM complaints GROUP BY category ORDER BY count DESC");
$byCategory = [];
while ($row = $categoryResult->fetch_assoc()) {
    $byCategory[] = $row;
}

// Get complaints by provider
$providerResult = $conn->query("SELECT provider_name, COUNT(*) as total, 
    SUM(CASE WHEN status = 'Resolved' THEN 1 ELSE 0 END) as resolved 
    FROM complaints GROUP BY provider_name ORDER BY total DESC LIMIT 10");
$byProvider = [];
while ($row = $providerResult->fetch_assoc()) {
    $byProvider[] = $row;
}

// Get recent complaints
$recentResult = $conn->query("SELECT complaint_number, category, provider_name, status, created_at FROM complaints ORDER BY created_at DESC LIMIT 10");
$recent = [];
while ($row = $recentResult->fetch_assoc()) {
    $row['created_at'] = date('Y-m-d H:i', strtotime($row['created_at']));
    $recent[] = $row;
}

echo json_encode([
    'success' => true,
    'stats' => [
        'total' => $total,
        'resolved' => $resolved,
        'under_review' => $underReview,
        'submitted' => $submitted,
        'resolution_rate' => $resolutionRate
    ],
    'by_category' => $byCategory,
    'by_provider' => $byProvider,
    'recent' => $recent
]);

$conn->close();
?>