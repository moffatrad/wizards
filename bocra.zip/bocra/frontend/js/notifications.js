// Notification System for BOCRA
class BOCRANotifications {
    constructor() {
        this.notifications = [];
        this.checkInterval = null;
    }
    
    init() {
        this.loadNotifications();
        this.createNotificationPanel();
        this.startChecking();
    }
    
    createNotificationPanel() {
        const panelHTML = `
            <div id="notification-panel" style="position: fixed; top: 100px; right: 80px; z-index: 999;">
                <button id="notification-toggle" style="background: #ff6600; color: white; border: none; border-radius: 50%; width: 45px; height: 45px; cursor: pointer; box-shadow: 0 2px 10px rgba(0,0,0,0.2); position: relative;">
                    🔔
                    <span id="notification-badge" style="position: absolute; top: -5px; right: -5px; background: red; color: white; border-radius: 50%; padding: 2px 6px; font-size: 12px; display: none;"></span>
                </button>
                <div id="notification-menu" style="display: none; position: absolute; top: 55px; right: 0; background: white; border-radius: 10px; box-shadow: 0 5px 20px rgba(0,0,0,0.2); width: 350px; max-height: 500px; overflow-y: auto;">
                    <div style="padding: 15px; border-bottom: 1px solid #eee;">
                        <strong>Notifications</strong>
                        <button id="clear-notifications" style="float: right; background: none; border: none; color: #ff6600; cursor: pointer;">Clear All</button>
                    </div>
                    <div id="notifications-list"></div>
                </div>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', panelHTML);
        
        document.getElementById('notification-toggle').onclick = () => {
            const menu = document.getElementById('notification-menu');
            menu.style.display = menu.style.display === 'none' ? 'block' : 'none';
            if (menu.style.display === 'block') {
                this.markAsRead();
            }
        };
        
        document.getElementById('clear-notifications').onclick = () => {
            this.clearAll();
        };
        
        this.updateBadge();
        this.renderNotifications();
    }
    
    addNotification(title, message, type = 'info') {
        const notification = {
            id: Date.now(),
            title,
            message,
            type,
            timestamp: new Date().toISOString(),
            read: false
        };
        
        this.notifications.unshift(notification);
        this.saveNotifications();
        this.renderNotifications();
        this.updateBadge();
        
        // Show browser notification
        if (localStorage.getItem('notifications') === 'enabled' && 'Notification' in window) {
            new Notification(title, { body: message });
        }
    }
    
    renderNotifications() {
        const container = document.getElementById('notifications-list');
        if (!container) return;
        
        if (this.notifications.length === 0) {
            container.innerHTML = '<div style="padding: 20px; text-align: center; color: #666;">No notifications</div>';
            return;
        }
        
        container.innerHTML = this.notifications.map(n => `
            <div style="padding: 15px; border-bottom: 1px solid #eee; ${!n.read ? 'background: #f0f8ff;' : ''}">
                <div style="display: flex; justify-content: space-between; margin-bottom: 5px;">
                    <strong style="color: ${this.getTypeColor(n.type)}">${this.getTypeIcon(n.type)} ${n.title}</strong>
                    <small style="color: #999;">${this.formatTime(n.timestamp)}</small>
                </div>
                <p style="margin: 5px 0 0 0; font-size: 13px; color: #666;">${n.message}</p>
            </div>
        `).join('');
    }
    
    updateBadge() {
        const unreadCount = this.notifications.filter(n => !n.read).length;
        const badge = document.getElementById('notification-badge');
        if (badge) {
            if (unreadCount > 0) {
                badge.textContent = unreadCount > 9 ? '9+' : unreadCount;
                badge.style.display = 'block';
            } else {
                badge.style.display = 'none';
            }
        }
    }
    
    markAsRead() {
        this.notifications.forEach(n => n.read = true);
        this.saveNotifications();
        this.updateBadge();
    }
    
    clearAll() {
        this.notifications = [];
        this.saveNotifications();
        this.renderNotifications();
        this.updateBadge();
    }
    
    startChecking() {
        // Check for new notifications every 30 seconds
        this.checkInterval = setInterval(() => {
            this.checkForUpdates();
        }, 30000);
    }
    
    checkForUpdates() {
        // Simulate checking for new updates
        // In production, this would call an API endpoint
        const now = new Date();
        const hour = now.getHours();
        
        // Random check for new content (demo)
        const updates = [
            { title: 'New Tender Available', message: 'A new tender for ICT equipment has been posted.', type: 'tender' },
            { title: 'License Application Update', message: 'Your license application is under review.', type: 'license' },
            { title: 'Complaint Resolution', message: 'Your complaint #BOCRA-2026-001 has been resolved.', type: 'complaint' },
            { title: 'System Maintenance', message: 'Scheduled maintenance on April 15, 2026.', type: 'info' }
        ];
        
        // Randomly add a notification (for demo)
        if (Math.random() < 0.3) { // 30% chance
            const randomUpdate = updates[Math.floor(Math.random() * updates.length)];
            this.addNotification(randomUpdate.title, randomUpdate.message, randomUpdate.type);
        }
    }
    
    getTypeIcon(type) {
        const icons = {
            tender: '📢',
            license: '📜',
            complaint: '📝',
            info: 'ℹ️',
            success: '✅',
            warning: '⚠️'
        };
        return icons[type] || '🔔';
    }
    
    getTypeColor(type) {
        const colors = {
            tender: '#ff6600',
            license: '#003366',
            complaint: '#28a745',
            info: '#17a2b8',
            success: '#28a745',
            warning: '#ffc107'
        };
        return colors[type] || '#666';
    }
    
    formatTime(timestamp) {
        const date = new Date(timestamp);
        const now = new Date();
        const diff = now - date;
        
        if (diff < 60000) return 'Just now';
        if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
        if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
        return date.toLocaleDateString();
    }
    
    saveNotifications() {
        localStorage.setItem('notifications', JSON.stringify(this.notifications));
    }
    
    loadNotifications() {
        const saved = localStorage.getItem('notifications');
        if (saved) {
            this.notifications = JSON.parse(saved);
        } else {
            // Add sample notifications
            this.addNotification('Welcome to BOCRA', 'Thank you for joining our platform!', 'success');
            this.addNotification('New Feature: Chatbot Assistant', 'Try our new AI assistant for help', 'info');
            this.addNotification('Upcoming: Two-Factor Authentication', 'Enhance your account security soon', 'warning');
        }
    }
}

// Initialize notifications
const notifications = new BOCRANotifications();
document.addEventListener('DOMContentLoaded', () => notifications.init());