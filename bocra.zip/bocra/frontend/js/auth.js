async function login(email, password, userType) {
  try {
    console.log("Sending login request to:", window.API_CONFIG.auth);
    
    const response = await fetch(window.API_CONFIG.auth, {
      method: "POST",
      headers: { 
        "Content-Type": "application/json",
        "Accept": "application/json"
      },
      body: JSON.stringify({
        action: "login",
        email: email,
        password: password,
        user_type: userType,
      }),
    });
    
    const data = await response.json();
    console.log("Login response:", data);
    return data;
  } catch (error) {
    console.error("Login error:", error);
    return { success: false, message: "Network error: " + error.message };
  }
}

async function register(userData) {
  try {
    console.log("Sending registration request to:", window.API_CONFIG.auth);
    
    const response = await fetch(window.API_CONFIG.auth, {
      method: "POST",
      headers: { 
        "Content-Type": "application/json",
        "Accept": "application/json"
      },
      body: JSON.stringify({ action: "register", ...userData }),
    });
    
    const data = await response.json();
    console.log("Registration response:", data);
    return data;
  } catch (error) {
    console.error("Register error:", error);
    return { success: false, message: "Network error: " + error.message };
  }
}

function isLoggedIn() {
  return localStorage.getItem("token") !== null;
}

function getCurrentUser() {
  const user = localStorage.getItem("user");
  return user ? JSON.parse(user) : null;
}

function logout() {
  localStorage.removeItem("token");
  localStorage.removeItem("user");
  localStorage.removeItem("userType");
  window.location.href = "index.html";
}

function showAlert(message, type) {
  const alertDiv = document.getElementById("alertMessage");
  if (alertDiv) {
    alertDiv.innerHTML = `<div class="alert alert-${type}">${message}</div>`;
    setTimeout(() => {
      alertDiv.innerHTML = "";
    }, 5000);
  } else {
    alert(message);
  }
}

window.auth = {
  login,
  register,
  isLoggedIn,
  getCurrentUser,
  logout,
  showAlert,
};