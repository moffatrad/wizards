// Dark Mode and Language Settings
class BOCRASettings {
    constructor() {
        this.darkMode = localStorage.getItem('darkMode') === 'true';
        this.language = localStorage.getItem('language') || 'en';
        this.translations = {
            en: {
                home: 'Home',
                about: 'About',
                file_complaint: 'File Complaint',
                track_complaint: 'Track Complaint',
                documents: 'Documents',
                projects: 'Projects',
                tenders: 'Tenders',
                apply_license: 'Apply License',
                dashboard: 'Dashboard',
                login: 'Login',
                logout: 'Logout',
                welcome: 'Welcome to BOCRA',
                connecting_botswana: 'Connecting Botswana. Protecting the Public.',
                file_complaint_now: 'File a Complaint Now',
                eservices: 'e-Services Portal'
            },
            tn: {
                home: 'Gae',
                about: 'Ka ga',
                file_complaint: 'Tsenya Tletlo',
                track_complaint: 'Latlha Tletlo',
                documents: 'Diokwalo',
                projects: 'DiPorojeke',
                tenders: 'Ditendara',
                apply_license: 'Kopa Laesense',
                dashboard: 'Botlhale',
                login: 'Tsena',
                logout: 'Tswa',
                welcome: 'O amogetswe mo BOCRA',
                connecting_botswana: 'Go golaganya Botswana. Go sireletsa Setšhaba.',
                file_complaint_now: 'Tsenya Tletlo Gonale',
                eservices: 'e-Services Portal'
            }
        };
    }
    
    init() {
        this.createSettingsPanel();
        this.applyDarkMode();
        this.applyLanguage();
    }
    
    createSettingsPanel() {
        const settingsHTML = `
            <div id="settings-panel" style="position: fixed; top: 100px; right: 20px; z-index: 999;">
                <button id="settings-toggle" style="background: #003366; color: white; border: none; border-radius: 50%; width: 50px; height: 50px; cursor: pointer; box-shadow: 0 2px 10px rgba(0,0,0,0.2); font-size: 20px;">
                    ⚙️
                </button>
                <div id="settings-menu" style="display: none; position: absolute; top: 60px; right: 0; background: white; border-radius: 10px; box-shadow: 0 5px 20px rgba(0,0,0,0.2); width: 250px; padding: 15px;">
                    <h4 style="margin: 0 0 15px 0;">Settings</h4>
                    
                    <div style="margin-bottom: 15px;">
                        <label>🌓 Dark Mode</label>
                        <label class="switch" style="float: right;">
                            <input type="checkbox" id="dark-mode-toggle" ${this.darkMode ? 'checked' : ''}>
                            <span class="slider"></span>
                        </label>
                        <div style="clear: both;"></div>
                    </div>
                    
                    <div style="margin-bottom: 15px;">
                        <label>🌐 Language</label>
                        <select id="language-select" style="float: right; padding: 5px; border-radius: 5px;">
                            <option value="en" ${this.language === 'en' ? 'selected' : ''}>English</option>
                            <option value="tn" ${this.language === 'tn' ? 'selected' : ''}>Setswana</option>
                        </select>
                        <div style="clear: both;"></div>
                    </div>
                    
                    <div style="margin-bottom: 15px;">
                        <label>🔔 Notifications</label>
                        <label class="switch" style="float: right;">
                            <input type="checkbox" id="notifications-toggle" checked>
                            <span class="slider"></span>
                        </label>
                        <div style="clear: both;"></div>
                    </div>
                    
                    <hr>
                    <button id="clear-data" style="width: 100%; padding: 8px; background: #dc3545; color: white; border: none; border-radius: 5px; cursor: pointer;">Clear Saved Data</button>
                </div>
            </div>
            <style>
                .switch {
                    position: relative;
                    display: inline-block;
                    width: 50px;
                    height: 24px;
                }
                .switch input {
                    opacity: 0;
                    width: 0;
                    height: 0;
                }
                .slider {
                    position: absolute;
                    cursor: pointer;
                    top: 0;
                    left: 0;
                    right: 0;
                    bottom: 0;
                    background-color: #ccc;
                    transition: .4s;
                    border-radius: 34px;
                }
                .slider:before {
                    position: absolute;
                    content: "";
                    height: 16px;
                    width: 16px;
                    left: 4px;
                    bottom: 4px;
                    background-color: white;
                    transition: .4s;
                    border-radius: 50%;
                }
                input:checked + .slider {
                    background-color: #ff6600;
                }
                input:checked + .slider:before {
                    transform: translateX(26px);
                }
            </style>
        `;
        
        document.body.insertAdjacentHTML('beforeend', settingsHTML);
        
        // Event listeners
        document.getElementById('settings-toggle').onclick = () => {
            const menu = document.getElementById('settings-menu');
            menu.style.display = menu.style.display === 'none' ? 'block' : 'none';
        };
        
        document.getElementById('dark-mode-toggle').onchange = (e) => {
            this.darkMode = e.target.checked;
            localStorage.setItem('darkMode', this.darkMode);
            this.applyDarkMode();
        };
        
        document.getElementById('language-select').onchange = (e) => {
            this.language = e.target.value;
            localStorage.setItem('language', this.language);
            this.applyLanguage();
        };
        
        document.getElementById('notifications-toggle').onchange = (e) => {
            if (e.target.checked) {
                this.requestNotificationPermission();
            } else {
                localStorage.setItem('notifications', 'disabled');
            }
        };
        
        document.getElementById('clear-data').onclick = () => {
            if (confirm('Clear all saved data? This will reset settings and log you out.')) {
                localStorage.clear();
                window.location.reload();
            }
        };
    }
    
    applyDarkMode() {
        if (this.darkMode) {
            document.body.style.background = '#1a1a1a';
            document.body.style.color = '#ffffff';
            document.querySelectorAll('.form-container, .sector-card, .table-container, .card, .about-section, .projects-section, .tenders-section, .license-section, .documents-section').forEach(el => {
                if (el) {
                    el.style.background = '#2d2d2d';
                    el.style.color = '#ffffff';
                }
            });
        } else {
            document.body.style.background = '';
            document.body.style.color = '';
            document.querySelectorAll('.form-container, .sector-card, .table-container, .card, .about-section, .projects-section, .tenders-section, .license-section, .documents-section').forEach(el => {
                if (el) {
                    el.style.background = '';
                    el.style.color = '';
                }
            });
        }
    }
    
    applyLanguage() {
        const elements = document.querySelectorAll('[data-translate]');
        elements.forEach(el => {
            const key = el.getAttribute('data-translate');
            if (this.translations[this.language][key]) {
                if (el.tagName === 'INPUT' && el.getAttribute('placeholder')) {
                    el.placeholder = this.translations[this.language][key];
                } else if (el.tagName === 'A' || el.tagName === 'BUTTON') {
                    el.textContent = this.translations[this.language][key];
                } else {
                    el.textContent = this.translations[this.language][key];
                }
            }
        });
        
        // Update navigation
        const navLinks = document.querySelectorAll('.nav-links a');
        const navTexts = ['home', 'about', 'file_complaint', 'track_complaint', 'documents', 'projects', 'tenders', 'apply_license', 'dashboard', 'login'];
        navLinks.forEach((link, index) => {
            if (index < navTexts.length) {
                link.textContent = this.translations[this.language][navTexts[index]];
            }
        });
    }
    
    requestNotificationPermission() {
        if ('Notification' in window) {
            Notification.requestPermission().then(permission => {
                if (permission === 'granted') {
                    localStorage.setItem('notifications', 'enabled');
                    this.showNotification('Welcome!', 'You will now receive BOCRA notifications');
                }
            });
        }
    }
    
    showNotification(title, body) {
        if (localStorage.getItem('notifications') === 'enabled' && 'Notification' in window) {
            new Notification(title, { body, icon: '/favicon.ico' });
        }
    }
}

// Initialize settings
const settings = new BOCRASettings();
document.addEventListener('DOMContentLoaded', () => settings.init());