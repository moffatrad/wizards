document.addEventListener("DOMContentLoaded", function () {
  updateUserMenu();
});

function updateUserMenu() {
  const user = localStorage.getItem("user");
  const navLinks = document.querySelector(".nav-links");

  if (user && navLinks) {
    const userData = JSON.parse(user);
    const loginLink = document.querySelector('a[href="login.html"]');

    if (loginLink) {
      if (userData.user_type === "admin") {
        loginLink.innerHTML = "👤 Admin";
        loginLink.href = "dashboard.html";
      } else if (userData.full_name) {
        loginLink.innerHTML = `👤 ${userData.full_name.split(" ")[0]}`;
        loginLink.href = "#";
      } else if (userData.company_name) {
        loginLink.innerHTML = `🏢 ${userData.company_name.split(" ")[0]}`;
        loginLink.href = "provider-dashboard.html";
      }

      if (!document.querySelector(".logout-link")) {
        const logoutLink = document.createElement("a");
        logoutLink.href = "#";
        logoutLink.innerHTML = "🚪 Logout";
        logoutLink.className = "logout-link";
        logoutLink.onclick = (e) => {
          e.preventDefault();
          auth.logout();
        };
        navLinks.appendChild(logoutLink);
      }
    }
  }
}
