// Chatbot Assistant for BOCRA System
class BOCRAChatbot {
    constructor() {
        this.isOpen = false;
        this.messages = [];
        this.suggestions = [
            "How do I file a complaint?",
            "What are the license requirements?",
            "How to track my complaint?",
            "What documents do I need?",
            "How to register as a supplier?",
            "Tell me about current tenders",
            "How to apply for spectrum license?",
            "What is the complaint resolution timeline?"
        ];
        this.responses = {
            "how do i file a complaint": "To file a complaint:\n1. Click on 'File Complaint' in the navigation menu\n2. Fill in the complaint form with details\n3. Upload supporting documents\n4. Submit and get your complaint number\n5. Track using your complaint number",
            
            "what are the license requirements": "License requirements vary by type. Generally you need:\n• Company registration\n• Tax clearance certificate\n• Business plan\n• Technical capabilities\n• Financial statements\n• Application fee payment\n\nVisit the License page for specific requirements.",
            
            "how to track my complaint": "Track your complaint by:\n1. Click 'Track Complaint'\n2. Enter your complaint number (e.g., BOCRA-2026-0001)\n3. View status and history\n4. Check provider responses",
            
            "what documents do i need": "Common documents needed:\n• Omang/ID/Passport\n• Company registration\n• Tax clearance\n• Proof of address\n• Bank statements\n• Technical qualifications\n• Business registration",
            
            "how to register as a supplier": "Supplier registration:\n1. Create an account as 'Company'\n2. Verify your email\n3. Submit company documents\n4. Wait for verification\n5. Start bidding on tenders",
            
            "tell me about current tenders": "Current tenders are available on the Tenders page. Open tenders include:\n• ICT Equipment Supply\n• Consultancy Services\n• Website Development\nCheck the Tenders page for details and deadlines.",
            
            "how to apply for spectrum license": "Spectrum license application:\n1. Login to your account\n2. Go to License page\n3. Select 'Spectrum License'\n4. Fill application form\n5. Upload technical specifications\n6. Pay application fee",
            
            "what is the complaint resolution timeline": "Complaint resolution timeline:\n• Acknowledgment: 48 hours\n• Provider response: 14 days\n• Resolution: Within 30 days\n• Escalation: If unsatisfied"
        };
    }

    init() {
        this.createChatWidget();
        this.loadMessages();
    }

    createChatWidget() {
        const chatHTML = `
            <div id="chatbot-widget" style="position: fixed; bottom: 20px; right: 20px; z-index: 1000;">
                <button id="chat-toggle" style="background: #1c1a19; color: white; border: none; border-radius: 50%; width: 60px; height: 60px; cursor: pointer; box-shadow: 0 2px 10px rgba(0,0,0,0.2); font-size: 24px;">
                    💬
                </button>
                <div id="chat-container" style="display: none; position: absolute; bottom: 80px; right: 0; width: 350px; height: 500px; background: white; border-radius: 10px; box-shadow: 0 5px 20px rgba(0,0,0,0.2); flex-direction: column; overflow: hidden;">
                    <div style="background: #003366; color: white; padding: 15px; display: flex; justify-content: space-between; align-items: center;">
                        <div>
                            <strong>BOCRA Assistant</strong>
                            <span style="font-size: 12px; display: block;">How can I help you today?</span>
                        </div>
                        <button id="chat-close" style="background: none; border: none; color: white; font-size: 20px; cursor: pointer;">×</button>
                    </div>
                    <div id="chat-messages" style="flex: 1; overflow-y: auto; padding: 15px; background: #f9f9f9;">
                        <div class="chat-message bot">
                            Hello! I'm BOCRA's virtual assistant. I can help you with complaints, licenses, tenders, and more. How can I assist you today?
                        </div>
                    </div>
                    <div id="chat-suggestions" style="padding: 10px; background: white; border-top: 1px solid #eee; display: flex; flex-wrap: wrap; gap: 8px;">
                        ${this.suggestions.map(s => `<button class="suggestion-btn" style="background: #f0f0f0; border: none; padding: 5px 10px; border-radius: 15px; cursor: pointer; font-size: 12px;">${s}</button>`).join('')}
                    </div>
                    <div style="padding: 10px; background: white; border-top: 1px solid #eee; display: flex;">
                        <input type="text" id="chat-input" placeholder="Type your question..." style="flex: 1; padding: 8px; border: 1px solid #ddd; border-radius: 5px; margin-right: 8px;">
                        <button id="chat-send" style="background: #0c0c0c; color: white; border: none; padding: 8px 15px; border-radius: 5px; cursor: pointer;">Send</button>
                    </div>
                </div>
            </div>
        `;
        
        document.body.insertAdjacentHTML('beforeend', chatHTML);
        
        // Add styles
        const style = document.createElement('style');
        style.textContent = `
            .chat-message {
                margin-bottom: 12px;
                padding: 8px 12px;
                border-radius: 10px;
                max-width: 85%;
                word-wrap: break-word;
            }
            .chat-message.user {
                background: #0c0b09;
                color: white;
                margin-left: auto;
            }
            .chat-message.bot {
                background: #e3f2fd;
                color: #333;
                margin-right: auto;
            }
            .suggestion-btn:hover {
                background: #ff6600 !important;
                color: white !important;
            }
        `;
        document.head.appendChild(style);
        
        // Event listeners
        document.getElementById('chat-toggle').onclick = () => this.toggleChat();
        document.getElementById('chat-close').onclick = () => this.closeChat();
        document.getElementById('chat-send').onclick = () => this.sendMessage();
        document.getElementById('chat-input').onkeypress = (e) => {
            if (e.key === 'Enter') this.sendMessage();
        };
        
        document.querySelectorAll('.suggestion-btn').forEach(btn => {
            btn.onclick = () => {
                document.getElementById('chat-input').value = btn.textContent;
                this.sendMessage();
            };
        });
    }
    
    toggleChat() {
        const container = document.getElementById('chat-container');
        this.isOpen = !this.isOpen;
        container.style.display = this.isOpen ? 'flex' : 'none';
        if (this.isOpen) {
            document.getElementById('chat-input').focus();
        }
    }
    
    closeChat() {
        this.isOpen = false;
        document.getElementById('chat-container').style.display = 'none';
    }
    
    sendMessage() {
        const input = document.getElementById('chat-input');
        const message = input.value.trim();
        if (!message) return;
        
        this.addMessage(message, 'user');
        input.value = '';
        
        // Get response
        setTimeout(() => {
            const response = this.getResponse(message.toLowerCase());
            this.addMessage(response, 'bot');
        }, 500);
    }
    
    addMessage(text, sender) {
        const messagesDiv = document.getElementById('chat-messages');
        const messageDiv = document.createElement('div');
        messageDiv.className = `chat-message ${sender}`;
        messageDiv.textContent = text;
        messagesDiv.appendChild(messageDiv);
        messagesDiv.scrollTop = messagesDiv.scrollHeight;
        
        this.messages.push({ text, sender });
        this.saveMessages();
    }
    
    getResponse(question) {
        // Check for keywords
        if (question.includes('complaint')) {
            return this.responses["how do i file a complaint"];
        } else if (question.includes('license') || question.includes('licence')) {
            return this.responses["what are the license requirements"];
        } else if (question.includes('track')) {
            return this.responses["how to track my complaint"];
        } else if (question.includes('document')) {
            return this.responses["what documents do i need"];
        } else if (question.includes('supplier') || question.includes('tender')) {
            return this.responses["how to register as a supplier"];
        } else if (question.includes('spectrum')) {
            return this.responses["how to apply for spectrum license"];
        } else if (question.includes('timeline') || question.includes('time')) {
            return this.responses["what is the complaint resolution timeline"];
        } else if (question.includes('hello') || question.includes('hi')) {
            return "Hello! How can I help you with BOCRA services today?";
        } else if (question.includes('thank')) {
            return "You're welcome! Is there anything else I can help you with?";
        } else {
            return "I'm not sure about that. Please visit our website or contact our support team at +267 395 7755 for assistance.";
        }
    }
    
    saveMessages() {
        localStorage.setItem('chat_history', JSON.stringify(this.messages));
    }
    
    loadMessages() {
        const saved = localStorage.getItem('chat_history');
        if (saved) {
            this.messages = JSON.parse(saved);
            // Optionally restore last few messages
        }
    }
}

// Initialize chatbot
const chatbot = new BOCRAChatbot();
document.addEventListener('DOMContentLoaded', () => chatbot.init());