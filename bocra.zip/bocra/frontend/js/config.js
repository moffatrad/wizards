// API Configuration for XAMPP
const API_BASE_URL = "http://localhost/bocra/backend/api";

const API_CONFIG = {
  baseUrl: API_BASE_URL,
  auth: API_BASE_URL + "/auth.php",
  complaints: API_BASE_URL + "/complaints.php",
  track: API_BASE_URL + "/track.php",
  dashboard: API_BASE_URL + "/dashboard.php",
  providerComplaints: API_BASE_URL + "/provider-complaints.php",
  providerRespond: API_BASE_URL + "/provider-respond.php",
};

window.API_CONFIG = API_CONFIG;
