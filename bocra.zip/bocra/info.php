<?php
echo "<h1>Server Information</h1>";
echo "<p>Current script: " . __FILE__ . "</p>";
echo "<p>Document root: " . $_SERVER['DOCUMENT_ROOT'] . "</p>";
echo "<h2>Checking folders:</h2>";

$folders = ['backend', 'backend/config', 'backend/api', 'frontend'];
foreach ($folders as $folder) {
    $path = __DIR__ . '/' . $folder;
    if (is_dir($path)) {
        echo "<p style='color:green'>✓ Found: $folder</p>";
        // List PHP files in config folder
        if ($folder == 'backend/config') {
            echo "<ul>";
            foreach (glob($path . '/*.php') as $file) {
                echo "<li>" . basename($file) . "</li>";
            }
            echo "</ul>";
        }
    } else {
        echo "<p style='color:red'>✗ Not found: $folder</p>";
    }
}
?>